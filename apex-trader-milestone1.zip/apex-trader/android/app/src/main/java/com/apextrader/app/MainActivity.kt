package com.apextrader.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val Graphite = Color(0xFF101318)
private val Panel = Color(0xFF1A2029)
private val Cyan = Color(0xFF42D9E8)
private val Violet = Color(0xFF9B8CFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ApexApp() }
    }
}

private data class WatchItem(val symbol: String, val label: String, val price: String, val note: String)
private val demoWatchlist = listOf(
    WatchItem("EURUSD", "Euro / US Dollar", "—", "No live feed connected"),
    WatchItem("XAUUSD", "Gold / US Dollar", "—", "No live feed connected"),
    WatchItem("BTCUSD", "Bitcoin / US Dollar", "—", "No live feed connected"),
    WatchItem("US100", "US Tech 100", "—", "Broker availability unverified"),
)

@Composable
private fun ApexApp() {
    var paperMode by remember { mutableStateOf(true) }
    var killSwitch by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("Overview") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, secondary = Violet, background = Graphite, surface = Panel)) {
        Scaffold(
            containerColor = Graphite,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Overview", "Markets", "Strategies", "Risk").forEach { tab ->
                        NavigationBarItem(selected = selectedTab == tab, onClick = { selectedTab = tab }, icon = {}, label = { Text(tab) })
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Spacer(Modifier.height(8.dp)); Header() }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Column {
                                    Text("EXECUTION MODE", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
                                    Text(if (paperMode) "PAPER TRADING" else "RESEARCH ONLY", color = Cyan, fontWeight = FontWeight.Bold)
                                }
                                Switch(checked = paperMode, onCheckedChange = { paperMode = it })
                            }
                            Text(if (paperMode) "Simulated only · no broker orders can be sent" else "Research mode · order execution disabled", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { SectionTitle(if (selectedTab == "Overview") "SYSTEM OVERVIEW" else selectedTab.uppercase()) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard("Broker", "Not connected", "No credentials stored", Modifier.weight(1f))
                        MetricCard("Market data", "Unavailable", "Live feed not connected", Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        MetricCard("Account equity", "—", "No account data", Modifier.weight(1f))
                        MetricCard("Open positions", "0", "No executions", Modifier.weight(1f))
                    }
                }
                item { SectionTitle("WATCHLIST") }
                items(demoWatchlist) { item -> WatchRow(item) }
                item { SectionTitle("RISK GUARD") }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("Default risk per trade", color = Color.LightGray)
                            Text("0.25% of equity", color = Cyan, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Daily loss lock: 1.00% · aggregate open risk: 1.00%", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.weight(1f)) {
                                    Text("Emergency stop", color = if (killSwitch) Color(0xFFFF7777) else Color.White, fontWeight = FontWeight.SemiBold)
                                    Text(if (killSwitch) "New trade proposals blocked locally" else "Execution is not connected in this build", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                                }
                                Button(onClick = { killSwitch = !killSwitch }) { Text(if (killSwitch) "RESET" else "STOP") }
                            }
                        }
                    }
                }
                item {
                    Text("Research build · illustrative interface · not financial advice. Stops may execute worse than requested during gaps or fast markets.", color = Color.Gray, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 18.dp))
                }
            }
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("APEX", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text("TRADER  /  QUANT TERMINAL", color = Cyan, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
        Surface(color = Color(0xFF392B16), shape = RoundedCornerShape(50)) {
            Text("OFFLINE", color = Color(0xFFFFD28A), modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Violet, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
}

@Composable
private fun MetricCard(title: String, value: String, note: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(note, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun WatchRow(item: WatchItem) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.symbol, color = Color.White, fontWeight = FontWeight.Bold)
                Text(item.label, color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                Text(item.note, color = Color.Gray, style = MaterialTheme.typography.labelSmall)
            }
            Text(item.price, color = Color.LightGray, fontWeight = FontWeight.Bold)
        }
    }
}
