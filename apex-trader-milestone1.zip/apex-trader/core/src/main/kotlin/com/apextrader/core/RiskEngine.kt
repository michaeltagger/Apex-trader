package com.apextrader.core

import kotlin.math.abs
import kotlin.math.floor

/** All money values must be expressed in the same account currency. */
data class RiskConfig(
    val riskPerTradeFraction: Double = 0.0025,
    val maxDailyLossFraction: Double = 0.01,
    val maxOpenRiskFraction: Double = 0.01,
    val maxLeverage: Double = 3.0,
    val maxSpreadFraction: Double = 0.001,
    val maxDataAgeMillis: Long = 5_000L,
) {
    init {
        require(riskPerTradeFraction in 0.0..0.01) { "Risk per trade must be between 0% and 1%" }
        require(maxDailyLossFraction in 0.0..0.05) { "Daily loss limit must be between 0% and 5%" }
        require(maxOpenRiskFraction in 0.0..0.05) { "Open risk limit must be between 0% and 5%" }
        require(maxLeverage > 0.0 && maxLeverage <= 20.0)
        require(maxSpreadFraction >= 0.0)
        require(maxDataAgeMillis > 0)
    }
}

data class AccountSnapshot(
    val equity: Double,
    val startOfDayEquity: Double,
    val openRisk: Double,
    val notionalExposure: Double,
    val freeMargin: Double,
)

data class MarketSnapshot(
    val bid: Double,
    val ask: Double,
    val observedAtMillis: Long,
    val nowMillis: Long,
)

data class OrderProposal(
    val side: Side,
    val entryPrice: Double,
    val stopPrice: Double,
    val units: Double,
    val unitValueInAccountCurrency: Double = 1.0,
    val estimatedMargin: Double = 0.0,
)

enum class Side { BUY, SELL }

data class RiskDecision(val approved: Boolean, val reasons: List<String>, val estimatedRisk: Double = 0.0) {
    companion object {
        fun reject(reason: String) = RiskDecision(false, listOf(reason))
    }
}

/** Pure deterministic gate. It does not place orders and must be called by the execution service. */
class RiskEngine(private val config: RiskConfig = RiskConfig()) {
    fun evaluate(
        account: AccountSnapshot,
        market: MarketSnapshot,
        proposal: OrderProposal,
        dailyLock: Boolean = false,
        killSwitchEngaged: Boolean = false,
    ): RiskDecision {
        if (killSwitchEngaged) return RiskDecision.reject("Global kill switch is engaged")
        if (dailyLock) return RiskDecision.reject("Daily trading lock is engaged")
        if (!account.equity.isFinite() || account.equity <= 0.0) return RiskDecision.reject("Invalid account equity")
        if (!account.startOfDayEquity.isFinite() || account.startOfDayEquity <= 0.0) return RiskDecision.reject("Invalid start-of-day equity")
        if (listOf(account.openRisk, account.notionalExposure, account.freeMargin).any { !it.isFinite() || it < 0.0 }) {
            return RiskDecision.reject("Invalid account exposure or margin data")
        }
        if (!market.bid.isFinite() || !market.ask.isFinite() || market.bid <= 0.0 || market.ask < market.bid) {
            return RiskDecision.reject("Invalid bid/ask market data")
        }
        if (market.nowMillis < market.observedAtMillis || market.nowMillis - market.observedAtMillis > config.maxDataAgeMillis) {
            return RiskDecision.reject("Market data is stale or clock is inconsistent")
        }
        val mid = (market.bid + market.ask) / 2.0
        val spreadFraction = (market.ask - market.bid) / mid
        if (spreadFraction > config.maxSpreadFraction) return RiskDecision.reject("Spread exceeds configured limit")
        if (!proposal.entryPrice.isFinite() || proposal.entryPrice <= 0.0 ||
            !proposal.stopPrice.isFinite() || proposal.stopPrice <= 0.0 ||
            !proposal.units.isFinite() || proposal.units <= 0.0 ||
            !proposal.unitValueInAccountCurrency.isFinite() || proposal.unitValueInAccountCurrency <= 0.0 ||
            !proposal.estimatedMargin.isFinite() || proposal.estimatedMargin < 0.0) {
            return RiskDecision.reject("Invalid order proposal values")
        }
        val stopIsValid = when (proposal.side) {
            Side.BUY -> proposal.stopPrice < proposal.entryPrice
            Side.SELL -> proposal.stopPrice > proposal.entryPrice
        }
        if (!stopIsValid) return RiskDecision.reject("Stop loss is not on the risk-limiting side of entry")
        if (proposal.estimatedMargin > account.freeMargin) return RiskDecision.reject("Insufficient free margin")

        val dailyLoss = (account.startOfDayEquity - account.equity).coerceAtLeast(0.0)
        if (dailyLoss >= account.startOfDayEquity * config.maxDailyLossFraction) {
            return RiskDecision.reject("Daily loss limit reached; trading locked")
        }
        val risk = abs(proposal.entryPrice - proposal.stopPrice) * proposal.units * proposal.unitValueInAccountCurrency
        if (!risk.isFinite()) return RiskDecision.reject("Estimated risk is not finite")
        if (risk > account.equity * config.riskPerTradeFraction + 1e-9) {
            return RiskDecision.reject("Trade risk exceeds configured per-trade limit")
        }
        if (account.openRisk + risk > account.equity * config.maxOpenRiskFraction + 1e-9) {
            return RiskDecision.reject("Aggregate open risk limit would be exceeded")
        }
        val proposedNotional = proposal.entryPrice * proposal.units * proposal.unitValueInAccountCurrency
        if ((account.notionalExposure + proposedNotional) / account.equity > config.maxLeverage) {
            return RiskDecision.reject("Maximum leverage would be exceeded")
        }
        return RiskDecision(true, listOf("Risk checks passed; this is not a guarantee of execution price"), risk)
    }

    /** Conservative stop-distance sizing helper; caller must still validate broker lot/tick rules. */
    fun sizeUnits(equity: Double, entry: Double, stop: Double, unitValue: Double = 1.0): Double {
        require(equity.isFinite() && equity > 0.0)
        require(entry.isFinite() && entry > 0.0 && stop.isFinite() && stop > 0.0 && entry != stop)
        require(unitValue.isFinite() && unitValue > 0.0)
        return floor((equity * config.riskPerTradeFraction) / (abs(entry - stop) * unitValue) * 1_000_000.0) / 1_000_000.0
    }
}
