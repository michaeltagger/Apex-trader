package com.apextrader.core

private fun assertTrue(value: Boolean, message: String) { if (!value) error(message) }
private fun assertFalse(value: Boolean, message: String) = assertTrue(!value, message)

fun main() {
    val engine = RiskEngine()
    val account = AccountSnapshot(equity = 10_000.0, startOfDayEquity = 10_000.0, openRisk = 0.0, notionalExposure = 0.0, freeMargin = 10_000.0)
    val market = MarketSnapshot(bid = 99.99, ask = 100.01, observedAtMillis = 10_000L, nowMillis = 10_500L)
    val safeBuy = OrderProposal(Side.BUY, entryPrice = 100.0, stopPrice = 99.8, units = 100.0, estimatedMargin = 100.0)

    assertTrue(engine.evaluate(account, market, safeBuy).approved, "safe proposal should pass")
    assertFalse(engine.evaluate(account, market, safeBuy, killSwitchEngaged = true).approved, "kill switch must reject")
    assertFalse(engine.evaluate(account, market, safeBuy, dailyLock = true).approved, "daily lock must reject")
    assertFalse(engine.evaluate(account, market.copy(observedAtMillis = 1L), safeBuy).approved, "stale market data must reject")
    assertFalse(engine.evaluate(account, market.copy(ask = 101.0), safeBuy).approved, "wide spread must reject")
    assertFalse(engine.evaluate(account, market, safeBuy.copy(stopPrice = 100.2)).approved, "buy stop above entry must reject")
    assertFalse(engine.evaluate(account, market, safeBuy.copy(units = 1_000.0)).approved, "excessive per-trade risk must reject")
    assertFalse(engine.evaluate(account.copy(equity = 9_900.0), market, safeBuy).approved, "daily loss limit must reject")
    assertFalse(engine.evaluate(account.copy(freeMargin = 1.0), market, safeBuy).approved, "insufficient margin must reject")
    assertFalse(engine.evaluate(account, market, safeBuy.copy(entryPrice = Double.NaN)).approved, "NaN must reject")
    val units = engine.sizeUnits(equity = 10_000.0, entry = 100.0, stop = 99.0)
    assertTrue(units == 25.0, "default 0.25% risk sizing expected 25 units; got $units")
    println("APEX TRADER risk-core tests: 11 passed")
}
