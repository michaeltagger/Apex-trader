#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
kotlinc \
  "$ROOT/core/src/main/kotlin/com/apextrader/core/RiskEngine.kt" \
  "$ROOT/core/src/test/kotlin/com/apextrader/core/RiskEngineTest.kt" \
  -include-runtime -d "$OUT/risk-tests.jar"
java -jar "$OUT/risk-tests.jar"
