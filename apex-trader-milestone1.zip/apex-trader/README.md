# APEX TRADER — Android-first foundation

Status: **Milestone 1 scaffold; not a live trading product.** The Android UI is designed around explicit Research / Paper Trading states. No broker is connected and all example prices/signals are illustrative. Live execution is deliberately absent.

## Modules

- `android/`: Kotlin + Jetpack Compose Android application source (requires Android SDK and Gradle/Android plugin to build).
- `core/`: pure Kotlin deterministic risk gate with no Android dependency.
- `scripts/test-core.sh`: compiles and executes core acceptance tests using `kotlinc`.
- `docs/ARCHITECTURE.md`: boundaries, safety properties, and next milestones.

## Test the risk core

Requirements: Kotlin compiler (`kotlinc`) and Java 17+.

```sh
./scripts/test-core.sh
```

## Android build

Open the `android/` directory in Android Studio with Android SDK installed. Gradle wrapper is not included in this first scaffold because Gradle/Android SDK are not installed in the inspected environment. Android dependencies must be resolved by Android Studio/Gradle before an APK can be built.

## Important limitations

- There is no broker adapter, live feed, AI model, or real execution in this milestone.
- Paper trading is not yet a realistic fill simulator; the UI only establishes explicit mode labels and risk visibility.
- Never enter broker credentials into this scaffold. Live trading must remain disabled until adapter, reconciliation, kill-switch, and risk acceptance tests pass.
