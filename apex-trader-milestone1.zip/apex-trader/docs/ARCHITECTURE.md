# Architecture and safety boundaries

```text
Android Compose UI
  ├── Mode / account-state presentation
  ├── Watchlist and signal explanation surfaces
  └── Risk status and emergency-stop surface
          │ typed contracts (future API boundary)
          ▼
Application API + authentication (not implemented)
  ├── Broker adapters: Deriv → MT5 bridge → OANDA → IBKR
  ├── Market data + normalized instrument metadata
  ├── Strategy engine / research
  ├── AI analysis (proposal-only)
  ├── Deterministic risk gate (implemented as pure Kotlin core)
  ├── Order management + reconciliation (not implemented)
  └── Journal, backtest, paper engine (future milestones)
```

## Invariants

1. AI analysis cannot authorize an order; only a deterministic risk gate may approve a proposal.
2. Research and paper modes never submit broker orders.
3. Missing, stale, invalid, or non-finite prices are rejected.
4. Risk per trade defaults to 0.25% of equity; daily loss lock defaults to 1% of start-of-day equity.
5. A daily loss lock or global kill switch rejects new proposals.
6. Stop-loss risk sizing is an estimate; gaps and slippage can exceed it.
7. No broker integration or live execution is claimed until verified against official documentation and an authorized sandbox/account.

## Milestone sequence

1. Foundation and deterministic risk gate (current).
2. Compose navigation, local Room persistence, watchlists and instrument model.
3. Historical data ingestion and reproducible backtest engine with costs.
4. Deriv official API adapter, initially read-only/demo and verified against current docs.
5. Paper execution, reconciliation and outage tests.
6. Additional broker adapters and AI analysis.
7. Controlled live pilot only after safety acceptance and explicit user activation.
